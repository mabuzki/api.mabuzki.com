<?php

namespace App\Modals;

use Illuminate\Database\Eloquent\Model;

class Attachment extends Model
{
    //
}
