<?php

namespace App\Modals;

use Illuminate\Database\Eloquent\Model;

class Article extends Model
{
    //
}
