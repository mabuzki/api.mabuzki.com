<?php

return [

    'avatar_tiny' => '28x28',
    'avatar_small' => '36x36',
    'avatar_medium' => '128x128',
    'avatar_large' => '180x180',

    

];
